#Requires -Version 5.1
<#
.SYNOPSIS
    JML Workflow Configuration — Hybrid AD + Entra ID
.DESCRIPTION
    Central config file. Edit this before running any JML scripts.
    All other scripts import this file via dot-sourcing.
#>

#region ── AD / Entra Settings ──────────────────────────────────────────────
$Global:JML = @{

    # ── Active Directory ──────────────────────────────────────────────────
    AD = @{
        DomainController    = "dc01.corp.contoso.com"   # Preferred DC for writes
        UserSearchBase      = "OU=Users,DC=corp,DC=contoso,DC=com"
        DisabledOU          = "OU=Disabled,OU=Users,DC=corp,DC=contoso,DC=com"
        GroupSearchBase     = "OU=Groups,DC=corp,DC=contoso,DC=com"

        # OU map by department. Add/remove as needed.
        DeptOUMap = @{
            "Engineering"   = "OU=Engineering,OU=Users,DC=corp,DC=contoso,DC=com"
            "Finance"       = "OU=Finance,OU=Users,DC=corp,DC=contoso,DC=com"
            "HR"            = "OU=HR,OU=Users,DC=corp,DC=contoso,DC=com"
            "Sales"         = "OU=Sales,OU=Users,DC=corp,DC=contoso,DC=com"
            "IT"            = "OU=IT,OU=Users,DC=corp,DC=contoso,DC=com"
            "Default"       = "OU=Users,DC=corp,DC=contoso,DC=com"
        }

        # Groups auto-added on every Joiner
        BaseGroups = @(
            "All-Staff",
            "VPN-Users",
            "O365-Licensed"
        )
    }

    # ── Entra ID (Azure AD) ───────────────────────────────────────────────
    Entra = @{
        TenantId            = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
        # Managed Identity or service principal app reg
        AppId               = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
        AppSecret           = $env:JML_APP_SECRET   # Store in env var / Key Vault
        # How long to wait for AD Connect delta sync (seconds)
        SyncWaitSeconds     = 300
        LicenseSKU          = @{
            "M365_E3"       = "05e9a617-0261-4cee-bb44-138d3ef5d965"
            "M365_E5"       = "06ebc4ee-1bb5-47dd-8120-11324bc54e06"
        }
        DefaultLicense      = "M365_E3"
    }

    # ── UPN / Username Policy ─────────────────────────────────────────────
    Naming = @{
        UPNSuffix           = "@contoso.com"
        # Options: "FirstLast" | "FLastInitial" | "FirstLInitial"
        UsernameFormat      = "FirstLast"
        # Max chars before numeric suffix added (clash prevention)
        MaxUsernameLength   = 20
        DisplayNameFormat   = "{FirstName} {LastName}"
    }

    # ── Password Policy ───────────────────────────────────────────────────
    Password = @{
        # Length of generated temp password
        TempPasswordLength  = 16
        # Force change at next logon (Joiner)
        MustChangeAtLogon   = $true
    }

    # ── Notifications ─────────────────────────────────────────────────────
    Notify = @{
        SMTPServer          = "smtp.contoso.com"
        SMTPPort            = 587
        FromAddress         = "it-noreply@contoso.com"
        ITTeamAddress       = "it-team@contoso.com"
        HRAddress           = "hr@contoso.com"
        # Managers receive Joiner welcome / Leaver confirmation emails
        NotifyManager       = $true
    }

    # ── Logging ───────────────────────────────────────────────────────────
    Logging = @{
        LogPath             = "C:\Logs\JML"
        RetentionDays       = 90
        # Options: "INFO" | "WARN" | "ERROR" | "DEBUG"
        LogLevel            = "INFO"
    }

    # ── Leaver ────────────────────────────────────────────────────────────
    Leaver = @{
        # Days to keep disabled account before deletion
        RetentionDays       = 90
        # Reassign mailbox contents to manager? Requires Exchange/EXO perms
        ForwardEmailToManager = $true
        # Revoke Entra tokens immediately on disable
        RevokeTokens        = $true
    }
}
#endregion
