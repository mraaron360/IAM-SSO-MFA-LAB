#Requires -Version 5.1
<#
.SYNOPSIS
    Shared helper functions used by all JML scripts.
    Dot-source this file: . "$PSScriptRoot\..\Helpers\JML-Helpers.ps1"
#>

#region ── Logging ────────────────────────────────────────────────────────────

function Write-JMLLog {
    param(
        [ValidateSet("INFO","WARN","ERROR","DEBUG")]
        [string]$Level = "INFO",
        [string]$Message,
        [string]$SAMAccountName = "",
        [switch]$PassThru
    )

    $logDir  = $Global:JML.Logging.LogPath
    $logFile = Join-Path $logDir "JML-$(Get-Date -f 'yyyy-MM').log"

    if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir | Out-Null }

    $minLevel = $Global:JML.Logging.LogLevel
    $levels   = @{ DEBUG=0; INFO=1; WARN=2; ERROR=3 }
    if ($levels[$Level] -lt $levels[$minLevel]) { return }

    $stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $user  = if ($SAMAccountName) { "[$SAMAccountName] " } else { "" }
    $entry = "$stamp [$Level] $user$Message"

    Add-Content -Path $logFile -Value $entry

    switch ($Level) {
        "ERROR" { Write-Host $entry -ForegroundColor Red }
        "WARN"  { Write-Host $entry -ForegroundColor Yellow }
        "DEBUG" { Write-Host $entry -ForegroundColor Cyan }
        default { Write-Host $entry }
    }

    if ($PassThru) { return $entry }
}

#endregion

#region ── Username / UPN Generation ─────────────────────────────────────────

function New-JMLUsername {
    param(
        [string]$FirstName,
        [string]$LastName
    )

    # Sanitise: strip diacritics, lowercase, remove non-alpha
    $clean = { param($s)
        $normalized = $s.Normalize([System.Text.NormalizationForm]::FormD)
        $ascii = ($normalized.ToCharArray() |
            Where-Object { [System.Globalization.CharUnicodeInfo]::GetUnicodeCategory($_) -ne
                           [System.Globalization.UnicodeCategory]::NonSpacingMark }) -join ''
        $ascii -replace '[^a-zA-Z]','' | ForEach-Object { $_.ToLower() }
    }

    $first = & $clean $FirstName
    $last  = & $clean $LastName
    $max   = $Global:JML.Naming.MaxUsernameLength

    $base = switch ($Global:JML.Naming.UsernameFormat) {
        "FirstLast"     { "$first$last" }
        "FLastInitial"  { "$($first.Substring(0,1))$last" }
        "FirstLInitial" { "$first$($last.Substring(0,1))" }
    }

    if ($base.Length -gt $max) { $base = $base.Substring(0, $max) }

    # Clash check — append numeric suffix if taken
    $candidate = $base
    $counter   = 1
    while (Get-ADUser -Filter "SamAccountName -eq '$candidate'" -ErrorAction SilentlyContinue) {
        $candidate = "$base$counter"
        $counter++
    }

    return $candidate
}

#endregion

#region ── Password Generation ───────────────────────────────────────────────

function New-JMLPassword {
    $len     = $Global:JML.Password.TempPasswordLength
    $upper   = 'ABCDEFGHJKLMNPQRSTUVWXYZ'.ToCharArray()
    $lower   = 'abcdefghjkmnpqrstuvwxyz'.ToCharArray()
    $digits  = '23456789'.ToCharArray()
    $special = '!@#$%&*+-=?'.ToCharArray()
    $all     = $upper + $lower + $digits + $special

    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()

    # Guarantee at least one of each required class
    $pwd  = @(
        $upper   | Get-Random
        $lower   | Get-Random
        $digits  | Get-Random
        $special | Get-Random
    )

    # Fill the rest
    for ($i = 4; $i -lt $len; $i++) {
        $pwd += $all | Get-Random
    }

    # Shuffle
    $shuffled = $pwd | Get-Random -Count $pwd.Count
    return ($shuffled -join '')
}

#endregion

#region ── Entra ID (Graph API) Helpers ──────────────────────────────────────

$script:_GraphToken = $null
$script:_GraphExpiry = [datetime]::MinValue

function Get-GraphToken {
    if ($script:_GraphToken -and [datetime]::UtcNow -lt $script:_GraphExpiry) {
        return $script:_GraphToken
    }

    $tenantId = $Global:JML.Entra.TenantId
    $appId    = $Global:JML.Entra.AppId
    $secret   = $Global:JML.Entra.AppSecret

    $body = @{
        grant_type    = "client_credentials"
        client_id     = $appId
        client_secret = $secret
        scope         = "https://graph.microsoft.com/.default"
    }

    try {
        $resp = Invoke-RestMethod -Method Post `
            -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" `
            -ContentType "application/x-www-form-urlencoded" `
            -Body $body
        $script:_GraphToken  = $resp.access_token
        $script:_GraphExpiry = [datetime]::UtcNow.AddSeconds($resp.expires_in - 60)
        return $script:_GraphToken
    }
    catch {
        Write-JMLLog -Level ERROR -Message "Failed to acquire Graph token: $_"
        throw
    }
}

function Invoke-GraphAPI {
    param(
        [string]$Method = "GET",
        [string]$Endpoint,
        [hashtable]$Body,
        [int]$RetryCount = 3
    )

    $token   = Get-GraphToken
    $baseUri = "https://graph.microsoft.com/v1.0"
    $uri     = "$baseUri/$Endpoint"
    $headers = @{ Authorization = "Bearer $token"; "Content-Type" = "application/json" }

    $attempt = 0
    while ($attempt -lt $RetryCount) {
        try {
            $params = @{ Method = $Method; Uri = $uri; Headers = $headers; ErrorAction = "Stop" }
            if ($Body) { $params.Body = ($Body | ConvertTo-Json -Depth 10) }
            return Invoke-RestMethod @params
        }
        catch {
            $attempt++
            $status = $_.Exception.Response?.StatusCode.value__
            if ($status -eq 429 -or $status -ge 500) {
                $wait = [math]::Pow(2, $attempt)
                Write-JMLLog -Level WARN -Message "Graph API $status — retry $attempt in ${wait}s"
                Start-Sleep -Seconds $wait
            }
            else { throw }
        }
    }
    throw "Graph API call failed after $RetryCount attempts: $Endpoint"
}

#endregion

#region ── AD Connect Sync ────────────────────────────────────────────────────

function Invoke-JMLADSync {
    param([switch]$Wait)

    Write-JMLLog -Level INFO -Message "Triggering AD Connect delta sync"
    try {
        # Runs sync on the AD Connect server (requires PSRemoting or local exec)
        Invoke-Command -ComputerName "adconnect.corp.contoso.com" -ScriptBlock {
            Import-Module ADSync
            Start-ADSyncSyncCycle -PolicyType Delta
        } -ErrorAction Stop
        Write-JMLLog -Level INFO -Message "Delta sync triggered"
    }
    catch {
        Write-JMLLog -Level WARN -Message "Could not trigger AD Connect sync: $_. Continuing without sync."
    }

    if ($Wait) {
        $secs = $Global:JML.Entra.SyncWaitSeconds
        Write-JMLLog -Level INFO -Message "Waiting ${secs}s for sync to complete"
        Start-Sleep -Seconds $secs
    }
}

#endregion

#region ── Email Notifications ───────────────────────────────────────────────

function Send-JMLEmail {
    param(
        [string[]]$To,
        [string]$Subject,
        [string]$Body,
        [string[]]$CC = @()
    )

    $smtp = $Global:JML.Notify
    try {
        $msg = @{
            From       = $smtp.FromAddress
            To         = $To
            Subject    = $Subject
            Body       = $Body
            BodyAsHtml = $false
            SmtpServer = $smtp.SMTPServer
            Port       = $smtp.SMTPPort
            UseSsl     = $true
        }
        if ($CC) { $msg.Cc = $CC }
        Send-MailMessage @msg
        Write-JMLLog -Level INFO -Message "Email sent: '$Subject' → $($To -join ', ')"
    }
    catch {
        Write-JMLLog -Level WARN -Message "Email failed: $_"
    }
}

#endregion
