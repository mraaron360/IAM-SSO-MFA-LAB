#Requires -Module Pester
<#
.SYNOPSIS
    Pester unit tests for JML-Helpers.ps1
    These tests do NOT require a live AD connection or Entra tenant.
    Run with: Invoke-Pester .\Tests\JML-Helpers.Tests.ps1 -Output Detailed
#>

BeforeAll {
    # Minimal config so helpers can load without a real environment
    $Global:JML = @{
        AD = @{
            DomainController = "dc01.test.local"
            DeptOUMap        = @{ "Engineering" = "OU=Eng,DC=test,DC=local"; "Default" = "OU=Users,DC=test,DC=local" }
            BaseGroups       = @("All-Staff")
        }
        Entra   = @{ TenantId = "test-tid"; AppId = "test-appid"; AppSecret = "test-secret"; SyncWaitSeconds = 5 }
        Naming  = @{ UPNSuffix = "@test.local"; UsernameFormat = "FirstLast"; MaxUsernameLength = 20; DisplayNameFormat = "{FirstName} {LastName}" }
        Password = @{ TempPasswordLength = 16; MustChangeAtLogon = $true }
        Notify  = @{ SMTPServer = "smtp.test.local"; SMTPPort = 587; FromAddress = "it@test.local"; ITTeamAddress = "it@test.local"; NotifyManager = $false }
        Logging = @{ LogPath = [System.IO.Path]::GetTempPath(); RetentionDays = 90; LogLevel = "ERROR" }
        Leaver  = @{ RetentionDays = 90; ForwardEmailToManager = $false; RevokeTokens = $true }
    }

    # Mock Get-ADUser so username generator doesn't need AD
    Mock Get-ADUser { return $null } -ModuleName "ActiveDirectory" -ParameterFilter { $Filter }

    . "$PSScriptRoot\..\Helpers\JML-Helpers.ps1"
}

Describe "New-JMLUsername" {

    Context "Standard formatting" {
        It "Returns FirstLast format correctly" {
            $result = New-JMLUsername -FirstName "Alice" -LastName "Smith"
            $result | Should -Be "alicesmith"
        }

        It "Lowercases the result" {
            $result = New-JMLUsername -FirstName "ALICE" -LastName "SMITH"
            $result | Should -MatchExactly "^[a-z]+$"
        }

        It "Strips diacritics from names" {
            $result = New-JMLUsername -FirstName "José" -LastName "García"
            $result | Should -Be "josegarcia"
        }

        It "Strips non-alpha characters" {
            $result = New-JMLUsername -FirstName "Mary-Jane" -LastName "O'Brien"
            $result | Should -Be "maryjaneobrien"
        }
    }

    Context "Length enforcement" {
        It "Truncates to MaxUsernameLength" {
            $Global:JML.Naming.MaxUsernameLength = 10
            $result = New-JMLUsername -FirstName "Christopher" -LastName "Longfellow"
            $result.Length | Should -BeLessOrEqual 10
            $Global:JML.Naming.MaxUsernameLength = 20
        }
    }

    Context "Alternative username formats" {
        It "Generates FLastInitial format" {
            $Global:JML.Naming.UsernameFormat = "FLastInitial"
            $result = New-JMLUsername -FirstName "Alice" -LastName "Smith"
            $result | Should -Be "asmith"
            $Global:JML.Naming.UsernameFormat = "FirstLast"
        }

        It "Generates FirstLInitial format" {
            $Global:JML.Naming.UsernameFormat = "FirstLInitial"
            $result = New-JMLUsername -FirstName "Alice" -LastName "Smith"
            $result | Should -Be "alices"
            $Global:JML.Naming.UsernameFormat = "FirstLast"
        }
    }
}

Describe "New-JMLPassword" {

    Context "Password generation" {
        It "Returns correct length" {
            $pwd = New-JMLPassword
            $pwd.Length | Should -Be $Global:JML.Password.TempPasswordLength
        }

        It "Contains at least one uppercase character" {
            $pwd = New-JMLPassword
            $pwd | Should -Match "[A-Z]"
        }

        It "Contains at least one lowercase character" {
            $pwd = New-JMLPassword
            $pwd | Should -Match "[a-z]"
        }

        It "Contains at least one digit" {
            $pwd = New-JMLPassword
            $pwd | Should -Match "[0-9]"
        }

        It "Contains at least one special character" {
            $pwd = New-JMLPassword
            $pwd | Should -Match "[!@#\$%&\*\+\-=\?]"
        }

        It "Returns different values on consecutive calls (not static)" {
            $p1 = New-JMLPassword
            $p2 = New-JMLPassword
            $p1 | Should -Not -Be $p2
        }
    }
}

Describe "Write-JMLLog" {

    Context "Log file creation" {
        It "Creates the log directory if it doesn't exist" {
            $testLogPath = Join-Path ([System.IO.Path]::GetTempPath()) "JML-Test-$(Get-Random)"
            $Global:JML.Logging.LogPath   = $testLogPath
            $Global:JML.Logging.LogLevel  = "INFO"

            Write-JMLLog -Level INFO -Message "Test entry"

            $testLogPath | Should -Exist
            Remove-Item $testLogPath -Recurse -Force
            $Global:JML.Logging.LogLevel = "ERROR"
        }

        It "Writes a log entry in the expected format" {
            $testLogPath = Join-Path ([System.IO.Path]::GetTempPath()) "JML-Test-$(Get-Random)"
            $Global:JML.Logging.LogPath  = $testLogPath
            $Global:JML.Logging.LogLevel = "INFO"

            Write-JMLLog -Level INFO -Message "Hello test" -SAMAccountName "testuser"

            $logFile = Get-ChildItem $testLogPath -Filter "*.log" | Select-Object -First 1
            $content = Get-Content $logFile.FullName
            $content | Should -Match "\[INFO\].*\[testuser\].*Hello test"

            Remove-Item $testLogPath -Recurse -Force
            $Global:JML.Logging.LogLevel = "ERROR"
        }
    }

    Context "Log level filtering" {
        It "Does not write DEBUG entries when level is ERROR" {
            $testLogPath = Join-Path ([System.IO.Path]::GetTempPath()) "JML-Test-$(Get-Random)"
            $Global:JML.Logging.LogPath  = $testLogPath
            $Global:JML.Logging.LogLevel = "ERROR"

            Write-JMLLog -Level DEBUG -Message "Should not appear"

            $logFiles = Get-ChildItem $testLogPath -Filter "*.log" -ErrorAction SilentlyContinue
            if ($logFiles) {
                $content = Get-Content $logFiles[0].FullName
                $content | Should -Not -Match "Should not appear"
            }
            # If no log file was created at all, that's also a pass
            Remove-Item $testLogPath -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}
