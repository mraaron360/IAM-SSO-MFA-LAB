#Requires -Version 5.1
<#
.SYNOPSIS
    JML CSV Trigger — Process a standardised HR export to drive JML actions

.DESCRIPTION
    Reads a CSV produced by your HRIS (Workday, BambooHR, etc.), compares
    each row against AD, and routes to Joiner / Mover / Leaver accordingly.

    Expected CSV columns:
        EmployeeID, FirstName, LastName, Action, Department, JobTitle,
        ManagerEmployeeID, StartDate, LeaveDate, MobilePhone, OfficeLocation

    Action values: JOINER | MOVER | LEAVER

    Schedule this script via Task Scheduler / Azure Automation to run daily.

.PARAMETER CSVPath
    Path to the HR export CSV.

.PARAMETER EmployeeIDAttribute
    The AD attribute used to store EmployeeID (default: EmployeeNumber).

.EXAMPLE
    .\JML-CSVTrigger.ps1 -CSVPath "\\fileserver\hr-exports\daily-jml.csv"
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)][string]$CSVPath,
    [string]$EmployeeIDAttribute = "EmployeeNumber"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
. "$root\Config\JML-Config.ps1"
. "$root\Helpers\JML-Helpers.ps1"

#region ── Validation ─────────────────────────────────────────────────────────
if (-not (Test-Path $CSVPath)) {
    Write-JMLLog -Level ERROR -Message "CSV not found: $CSVPath"
    throw "CSV not found: $CSVPath"
}

$rows = Import-Csv -Path $CSVPath
Write-JMLLog -Level INFO -Message "CSV loaded: $($rows.Count) row(s) from $CSVPath"
#endregion

#region ── Build EmployeeID → SAM Lookup ─────────────────────────────────────
# Cache so we don't hit AD per row
$adLookup = @{}
Get-ADUser -Filter * -Properties $EmployeeIDAttribute, SamAccountName |
    Where-Object { $_.$EmployeeIDAttribute } |
    ForEach-Object { $adLookup[$_.$EmployeeIDAttribute] = $_.SamAccountName }
#endregion

$summary = @{ Joiner=0; Mover=0; Leaver=0; Skipped=0; Error=0 }

foreach ($row in $rows) {

    $action = $row.Action.ToUpper().Trim()
    $empId  = $row.EmployeeID.Trim()
    $sam    = $adLookup[$empId]

    Write-JMLLog -Level INFO -Message "Processing [$action] EmpID=$empId"

    try {
        switch ($action) {

            "JOINER" {
                # Resolve manager SAM from ManagerEmployeeID
                $mgrSAM = $adLookup[$row.ManagerEmployeeID]
                if (-not $mgrSAM) {
                    Write-JMLLog -Level WARN -Message "Manager EmpID '$($row.ManagerEmployeeID)' not in AD — skipping row"
                    $summary.Skipped++; continue
                }

                $params = @{
                    FirstName        = $row.FirstName.Trim()
                    LastName         = $row.LastName.Trim()
                    Department       = $row.Department.Trim()
                    JobTitle         = $row.JobTitle.Trim()
                    ManagerSAM       = $mgrSAM
                    StartDate        = $row.StartDate.Trim()
                }
                if ($row.MobilePhone)    { $params.MobilePhone    = $row.MobilePhone.Trim() }
                if ($row.OfficeLocation) { $params.OfficeLocation = $row.OfficeLocation.Trim() }

                & "$root\Core\JML-Joiner.ps1" -InputObject $params
                $summary.Joiner++
            }

            "MOVER" {
                if (-not $sam) {
                    Write-JMLLog -Level WARN -Message "EmpID $empId not found in AD — cannot move"
                    $summary.Skipped++; continue
                }

                $changes = @{}
                if ($row.Department)     { $changes.Department  = $row.Department.Trim() }
                if ($row.JobTitle)       { $changes.JobTitle     = $row.JobTitle.Trim() }
                if ($row.ManagerEmployeeID -and $adLookup[$row.ManagerEmployeeID]) {
                    $changes.ManagerSAM = $adLookup[$row.ManagerEmployeeID]
                }
                if ($row.OfficeLocation) { $changes.OfficeLocation = $row.OfficeLocation.Trim() }

                & "$root\Core\JML-Mover.ps1" -SAMAccountName $sam -Changes $changes
                $summary.Mover++
            }

            "LEAVER" {
                if (-not $sam) {
                    Write-JMLLog -Level WARN -Message "EmpID $empId not found in AD — cannot offboard (may already be gone)"
                    $summary.Skipped++; continue
                }

                $reason = if ($row.PSObject.Properties["Reason"]) { $row.Reason } else { "HR export" }
                & "$root\Core\JML-Leaver.ps1" -SAMAccountName $sam -EffectiveDate $row.LeaveDate -Reason $reason
                $summary.Leaver++
            }

            default {
                Write-JMLLog -Level WARN -Message "Unknown action '$action' for EmpID $empId — skipped"
                $summary.Skipped++
            }
        }
    }
    catch {
        Write-JMLLog -Level ERROR -Message "Error processing EmpID $empId [$action]: $_"
        $summary.Error++
    }
}

#region ── Summary Email ──────────────────────────────────────────────────────
$body = @"
JML CSV run complete: $(Get-Date -Format 'yyyy-MM-dd HH:mm')
Source: $CSVPath

  Joiners : $($summary.Joiner)
  Movers  : $($summary.Mover)
  Leavers : $($summary.Leaver)
  Skipped : $($summary.Skipped)
  Errors  : $($summary.Error)

Check C:\Logs\JML for full details.
"@

$subject = "[JML] Daily run — J:$($summary.Joiner) M:$($summary.Mover) L:$($summary.Leaver)"
if ($summary.Error -gt 0) { $subject += " ⚠ $($summary.Error) error(s)" }

Send-JMLEmail -To @($Global:JML.Notify.ITTeamAddress) -Subject $subject -Body $body
Write-JMLLog -Level INFO -Message "=== CSV RUN COMPLETE: J=$($summary.Joiner) M=$($summary.Mover) L=$($summary.Leaver) E=$($summary.Error) ==="
#endregion
