# JML Automation — PowerShell Framework for Hybrid AD + Entra ID

> **Joiner · Mover · Leaver** — automated identity lifecycle management for organisations running on-premises Active Directory synced to Microsoft Entra ID (Azure AD) via AD Connect.

---

## Overview

This framework provisions, transfers, and offboards user accounts across the full identity stack:

- **Active Directory** — account creation, OU placement, group membership
- **Microsoft Entra ID** — licence assignment/removal, token revocation via Microsoft Graph API
- **Notifications** — manager and IT team alerts via SMTP
- **Audit logging** — every action timestamped and written to rotating log files
- **Retention + cleanup** — automated deletion of disabled accounts after configurable retention window

---

## Architecture

```
jml-automation-ps/
│
├── Config/
│   └── JML-Config.ps1        # Central config — edit before running
│
├── Helpers/
│   └── JML-Helpers.ps1       # Shared: logging, username gen, Graph API client, email
│
├── Core/
│   ├── JML-Joiner.ps1        # Provision new starters
│   ├── JML-Mover.ps1         # Handle internal transfers / role changes
│   ├── JML-Leaver.ps1        # Offboard departing users
│   └── JML-Cleanup.ps1       # Weekly retention purge of disabled accounts
│
├── Triggers/
│   └── JML-CSVTrigger.ps1    # HR feed processor — runs daily, routes all three actions
│
└── Tests/
    └── JML-Helpers.Tests.ps1 # Pester unit tests for helper functions
```

---

## Prerequisites

| Requirement | Notes |
|---|---|
| PowerShell 5.1+ | Or PowerShell 7+ (cross-platform) |
| RSAT: Active Directory | `Add-WindowsFeature RSAT-AD-PowerShell` |
| PSRemoting to AD Connect server | For manual delta sync trigger |
| Entra App Registration | With `User.ReadWrite.All` + `Directory.ReadWrite.All` + `Organization.Read.All` |
| SMTP relay | Internal relay or Exchange connector |
| Azure Key Vault (recommended) | For secret storage — see Security section |

---

## Quick Start

### 1. Configure

Edit `Config/JML-Config.ps1` for your environment:

```powershell
$Global:JML = @{
    AD = @{
        DomainController = "dc01.corp.contoso.com"
        DeptOUMap = @{
            "Engineering" = "OU=Engineering,OU=Users,DC=corp,DC=contoso,DC=com"
            # Add your departments...
        }
    }
    Entra = @{
        TenantId = "your-tenant-id"
        AppId    = "your-app-id"
        # App secret loaded from env var / Key Vault — never hardcode
    }
    # ... see Config/JML-Config.ps1 for all options
}
```

Set the app secret as an environment variable (or retrieve from Key Vault):

```powershell
$env:JML_APP_SECRET = "your-secret-here"   # Dev only — use Key Vault in prod
```

### 2. Run a Joiner

```powershell
$newUser = @{
    FirstName        = "Alice"
    LastName         = "Smith"
    Department       = "Engineering"
    JobTitle         = "Software Engineer"
    ManagerSAM       = "jdoe"
    StartDate        = "2025-06-01"
    MobilePhone      = "+447911123456"
    AdditionalGroups = @("GitHub-Users", "Jira-Engineering")
}

.\Core\JML-Joiner.ps1 -InputObject $newUser -WhatIf   # Dry run first
.\Core\JML-Joiner.ps1 -InputObject $newUser            # Execute
```

### 3. Run a Leaver

```powershell
.\Core\JML-Leaver.ps1 -SAMAccountName "asmith" -Reason "Resignation" -WhatIf
.\Core\JML-Leaver.ps1 -SAMAccountName "asmith" -Reason "Resignation"
```

### 4. Process an HR export (automated)

```powershell
.\Triggers\JML-CSVTrigger.ps1 -CSVPath "\\fileserver\hr-exports\daily-jml.csv"
```

Expected CSV columns: `EmployeeID, FirstName, LastName, Action, Department, JobTitle, ManagerEmployeeID, StartDate, LeaveDate, MobilePhone, OfficeLocation`

Action values: `JOINER`, `MOVER`, `LEAVER`

---

## Scheduling

### Task Scheduler (on-prem)

```powershell
# Create a scheduled task to run the CSV trigger daily at 07:00
$action  = New-ScheduledTaskAction -Execute "powershell.exe" `
    -Argument "-NonInteractive -File C:\JML\Triggers\JML-CSVTrigger.ps1 -CSVPath \\server\hr\daily.csv"
$trigger = New-ScheduledTaskTrigger -Daily -At "07:00"
Register-ScheduledTask -TaskName "JML-DailyRun" -Action $action -Trigger $trigger `
    -RunLevel Highest -User "DOMAIN\svc-jml"
```

### Azure Automation Runbook

Import `Triggers/JML-CSVTrigger.ps1` as a PowerShell runbook. Use a Managed Identity for credential access and store the HR CSV in a Storage Account blob, fetching it at runtime.

---

## Leaver process — step by step

| Step | Action | Notes |
|---|---|---|
| 1 | `Disable-ADAccount` | Immediate — stops new authentications |
| 2 | `revokeSignInSessions` (Graph) | Invalidates all existing Entra tokens |
| 3 | Clear manager, randomise password | Prevents re-enable without IT involvement |
| 4 | `Remove-ADGroupMember` (all groups) | Skips Domain Users (primary group) |
| 5 | `Move-ADObject` → Disabled OU | Separates from active user pool |
| 6 | `Set-ADUser -Description` | Stamps date, reason, operator for audit |
| 7 | Remove Entra licences (Graph) | Releases licence seat immediately |
| 8 | Notify manager + IT | Confirmation with action summary |
| 9 | `JML-Cleanup.ps1` (weekly) | Deletes after retention window expires |

---

## Security considerations

### Secrets management

**Never hardcode credentials.** The recommended pattern:

```powershell
# Retrieve from Azure Key Vault using Managed Identity
$secret = Get-AzKeyVaultSecret -VaultName "kv-jml-prod" -Name "EntraAppSecret" -AsPlainText
$env:JML_APP_SECRET = $secret
```

### Entra App Registration permissions

Minimum required Microsoft Graph API permissions (Application, not Delegated):

| Permission | Reason |
|---|---|
| `User.ReadWrite.All` | Create, update, disable users |
| `Directory.ReadWrite.All` | Group membership |
| `Organization.Read.All` | Read licence SKU IDs |

### Service account

Run scripts under a dedicated service account (`svc-jml`) with:
- No interactive logon rights
- AD rights scoped to target OUs only (delegated, not Domain Admin)
- Audit logging enabled on the account

---

## Logging

Logs written to `C:\Logs\JML\JML-yyyy-MM.log` (configurable). Format:

```
2025-05-27 07:14:23 [INFO] [asmith] AD account created in OU: OU=Engineering,...
2025-05-27 07:14:24 [INFO] [asmith] Added to group: All-Staff
2025-05-27 07:14:29 [INFO] [asmith] Delta sync triggered
2025-05-27 07:15:03 [INFO] [asmith] Licence assigned: M365_E3
```

Log files are retained for 90 days (configurable in `JML-Config.ps1`).

---

## Testing

```powershell
# Install Pester
Install-Module -Name Pester -Force -SkipPublisherCheck

# Run unit tests (no live AD required)
Invoke-Pester .\Tests\JML-Helpers.Tests.ps1 -Output Detailed

# Dry-run any script in production
.\Core\JML-Joiner.ps1 -InputObject $params -WhatIf
.\Core\JML-Leaver.ps1 -SAMAccountName "testuser" -WhatIf
```

---

## Contributing

1. Fork the repo
2. Create a feature branch: `git checkout -b feature/your-change`
3. All new functions must have comment-based help (`Get-Help`)
4. Add Pester tests for any new helper functions
5. Test with `-WhatIf` before submitting a PR
6. Open a pull request with a description of the change and any AD/Entra permissions required

---

## Licence

MIT — see [LICENSE](LICENSE)

---

## Related resources

- [Microsoft Graph API — User operations](https://learn.microsoft.com/en-us/graph/api/resources/user)
- [AD Connect delta sync](https://learn.microsoft.com/en-us/azure/active-directory/hybrid/connect/how-to-connect-sync-feature-scheduler)
- [Entra token revocation](https://learn.microsoft.com/en-us/azure/active-directory/enterprise-users/users-revoke-access)
- [Pester testing framework](https://pester.dev)
