#Requires -Version 5.1
#Requires -Modules ActiveDirectory
<#
.SYNOPSIS
    JML Cleanup — Purge disabled accounts that have exceeded the retention window.

.DESCRIPTION
    Run weekly via Task Scheduler. Queries the Disabled OU, checks the account
    description for the DISABLED date stamp written by JML-Leaver, and deletes
    accounts older than Leaver.RetentionDays. Exports a pre-delete report first.
#>
[CmdletBinding(SupportsShouldProcess)]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
. "$root\Config\JML-Config.ps1"
. "$root\Helpers\JML-Helpers.ps1"

$retentionDays = $Global:JML.Leaver.RetentionDays
$disabledOU    = $Global:JML.AD.DisabledOU
$cutoff        = (Get-Date).AddDays(-$retentionDays)
$reportPath    = Join-Path $Global:JML.Logging.LogPath "Cleanup-$(Get-Date -f 'yyyy-MM-dd').csv"

Write-JMLLog -Level INFO -Message "=== CLEANUP START (retention: ${retentionDays}d, cutoff: $($cutoff.ToString('yyyy-MM-dd'))) ==="

$candidates = Get-ADUser -Filter * `
    -SearchBase $disabledOU `
    -Properties Description, WhenCreated, SamAccountName, DisplayName `
    -Server $Global:JML.AD.DomainController

$toDelete = $candidates | Where-Object {
    # Parse the date stamp written by JML-Leaver: "DISABLED 2025-01-15 | ..."
    if ($_.Description -match 'DISABLED (\d{4}-\d{2}-\d{2})') {
        [datetime]::ParseExact($Matches[1], "yyyy-MM-dd", $null) -lt $cutoff
    } else {
        # Fallback: use WhenCreated if no description stamp
        $_.WhenCreated -lt $cutoff
    }
}

Write-JMLLog -Level INFO -Message "Found $($toDelete.Count) account(s) eligible for deletion"

# Export pre-delete report
$toDelete | Select-Object SamAccountName, DisplayName, Description, WhenCreated |
    Export-Csv -Path $reportPath -NoTypeInformation
Write-JMLLog -Level INFO -Message "Pre-delete report: $reportPath"

$deleted = 0; $errors = 0
foreach ($user in $toDelete) {
    if ($PSCmdlet.ShouldProcess($user.SamAccountName, "Delete AD account")) {
        try {
            Remove-ADUser -Identity $user.SamAccountName `
                          -Server $Global:JML.AD.DomainController -Confirm:$false
            Write-JMLLog -Level INFO -Message "Deleted: $($user.SamAccountName) | $($user.Description)" -SAMAccountName $user.SamAccountName
            $deleted++
        }
        catch {
            Write-JMLLog -Level ERROR -Message "Delete failed for $($user.SamAccountName): $_" -SAMAccountName $user.SamAccountName
            $errors++
        }
    }
}

Send-JMLEmail -To @($Global:JML.Notify.ITTeamAddress) `
    -Subject "[JML] Weekly cleanup — $deleted deleted, $errors errors" `
    -Body "Cleanup run $(Get-Date -f 'yyyy-MM-dd'). Deleted: $deleted. Errors: $errors. Report: $reportPath"

Write-JMLLog -Level INFO -Message "=== CLEANUP COMPLETE: $deleted deleted, $errors errors ==="
