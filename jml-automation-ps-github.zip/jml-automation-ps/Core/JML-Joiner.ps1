#Requires -Version 5.1
#Requires -Modules ActiveDirectory
<#
.SYNOPSIS
    JML Joiner — Provision a new user in AD + Entra ID

.DESCRIPTION
    Creates the AD account, sets group memberships, triggers AD Connect sync,
    assigns the M365 licence in Entra, and notifies IT + manager.

.PARAMETER InputObject
    Hashtable or PSCustomObject with the fields below. All are mandatory
    unless marked optional.

    Required:
        FirstName, LastName, Department, JobTitle, ManagerSAM, StartDate

    Optional:
        MobilePhone, OfficeLocation, AdditionalGroups (string[])

.EXAMPLE
    $user = @{
        FirstName        = "Alice"
        LastName         = "Smith"
        Department       = "Engineering"
        JobTitle         = "Software Engineer"
        ManagerSAM       = "jdoe"
        StartDate        = "2025-06-01"
        MobilePhone      = "+447911123456"
        OfficeLocation   = "London"
        AdditionalGroups = @("GitHub-Users","Jira-Engineering")
    }
    .\JML-Joiner.ps1 -InputObject $user
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)]
    [hashtable]$InputObject
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ── Bootstrap ──────────────────────────────────────────────────────────────────
$root = Split-Path -Parent $PSScriptRoot
. "$root\Config\JML-Config.ps1"
. "$root\Helpers\JML-Helpers.ps1"

Write-JMLLog -Level INFO -Message "=== JOINER START: $($InputObject.FirstName) $($InputObject.LastName) ==="

#region ── 1. Validate Input ──────────────────────────────────────────────────
$required = @("FirstName","LastName","Department","JobTitle","ManagerSAM","StartDate")
foreach ($field in $required) {
    if (-not $InputObject.ContainsKey($field) -or [string]::IsNullOrWhiteSpace($InputObject[$field])) {
        Write-JMLLog -Level ERROR -Message "Missing required field: $field"
        throw "Missing required field: $field"
    }
}

$dept = $InputObject.Department
$ou   = if ($Global:JML.AD.DeptOUMap.ContainsKey($dept)) {
            $Global:JML.AD.DeptOUMap[$dept]
        } else {
            Write-JMLLog -Level WARN -Message "Dept '$dept' not in OUMap — using Default OU"
            $Global:JML.AD.DeptOUMap["Default"]
        }
#endregion

#region ── 2. Generate Username & Password ─────────────────────────────────────
$sam      = New-JMLUsername -FirstName $InputObject.FirstName -LastName $InputObject.LastName
$upn      = "$sam$($Global:JML.Naming.UPNSuffix)"
$password = New-JMLPassword
$secPwd   = ConvertTo-SecureString $password -AsPlainText -Force

Write-JMLLog -Level INFO -Message "Generated username: $sam / UPN: $upn" -SAMAccountName $sam
#endregion

#region ── 3. Resolve Manager ─────────────────────────────────────────────────
try {
    $manager = Get-ADUser -Identity $InputObject.ManagerSAM `
                          -Properties EmailAddress `
                          -Server $Global:JML.AD.DomainController
    Write-JMLLog -Level INFO -Message "Manager resolved: $($manager.SamAccountName)" -SAMAccountName $sam
}
catch {
    Write-JMLLog -Level ERROR -Message "Manager SAM '$($InputObject.ManagerSAM)' not found in AD" -SAMAccountName $sam
    throw
}
#endregion

#region ── 4. Create AD Account ───────────────────────────────────────────────
if ($PSCmdlet.ShouldProcess($sam, "Create AD account")) {

    $displayName = $Global:JML.Naming.DisplayNameFormat `
        -replace '\{FirstName\}', $InputObject.FirstName `
        -replace '\{LastName\}',  $InputObject.LastName

    $adParams = @{
        SamAccountName        = $sam
        UserPrincipalName     = $upn
        GivenName             = $InputObject.FirstName
        Surname               = $InputObject.LastName
        DisplayName           = $displayName
        Name                  = $displayName
        Department            = $dept
        Title                 = $InputObject.JobTitle
        Manager               = $manager.DistinguishedName
        AccountPassword       = $secPwd
        ChangePasswordAtLogon = $Global:JML.Password.MustChangeAtLogon
        Enabled               = $true
        Path                  = $ou
        Server                = $Global:JML.AD.DomainController
        PassThru              = $true
    }

    if ($InputObject.MobilePhone)    { $adParams.MobilePhone    = $InputObject.MobilePhone }
    if ($InputObject.OfficeLocation) { $adParams.Office         = $InputObject.OfficeLocation }

    try {
        $newUser = New-ADUser @adParams
        Write-JMLLog -Level INFO -Message "AD account created in OU: $ou" -SAMAccountName $sam
    }
    catch {
        Write-JMLLog -Level ERROR -Message "New-ADUser failed: $_" -SAMAccountName $sam
        throw
    }
}
#endregion

#region ── 5. Group Memberships ───────────────────────────────────────────────
$groups = $Global:JML.AD.BaseGroups
if ($InputObject.ContainsKey("AdditionalGroups")) {
    $groups += $InputObject.AdditionalGroups
}

foreach ($grp in $groups) {
    try {
        Add-ADGroupMember -Identity $grp -Members $sam -Server $Global:JML.AD.DomainController
        Write-JMLLog -Level INFO -Message "Added to group: $grp" -SAMAccountName $sam
    }
    catch {
        Write-JMLLog -Level WARN -Message "Failed to add to group '$grp': $_" -SAMAccountName $sam
    }
}
#endregion

#region ── 6. AD Connect Sync → Entra ────────────────────────────────────────
Invoke-JMLADSync -Wait

# Verify the object landed in Entra
$retry = 0; $entraUser = $null
while ($retry -lt 6 -and -not $entraUser) {
    Start-Sleep -Seconds 30
    try {
        $entraUser = Invoke-GraphAPI -Endpoint "users/$upn" -ErrorAction SilentlyContinue
    } catch {}
    $retry++
}

if (-not $entraUser) {
    Write-JMLLog -Level WARN -Message "User not found in Entra after sync — licence assignment skipped" -SAMAccountName $sam
}
#endregion

#region ── 7. Assign M365 Licence ─────────────────────────────────────────────
if ($entraUser) {
    $skuId    = $Global:JML.Entra.LicenseSKU[$Global:JML.Entra.DefaultLicense]
    $licBody  = @{
        addLicenses    = @(@{ skuId = $skuId; disabledPlans = @() })
        removeLicenses = @()
    }

    try {
        Invoke-GraphAPI -Method POST -Endpoint "users/$upn/assignLicense" -Body $licBody
        Write-JMLLog -Level INFO -Message "Licence assigned: $($Global:JML.Entra.DefaultLicense)" -SAMAccountName $sam
    }
    catch {
        Write-JMLLog -Level WARN -Message "Licence assignment failed: $_" -SAMAccountName $sam
    }
}
#endregion

#region ── 8. Notifications ───────────────────────────────────────────────────
if ($Global:JML.Notify.NotifyManager -and $manager.EmailAddress) {
    Send-JMLEmail -To @($manager.EmailAddress) `
        -CC @($Global:JML.Notify.ITTeamAddress) `
        -Subject "New starter: $displayName starts $($InputObject.StartDate)" `
        -Body @"
Hi $($manager.GivenName),

$displayName will be joining $dept on $($InputObject.StartDate).

Their account details:
  Username : $sam
  UPN      : $upn
  Password : $password  ← Communicate this securely. User must change on first login.

Licence    : $($Global:JML.Entra.DefaultLicense)
Groups     : $($groups -join ', ')

If anything looks wrong, reply to this email.

— IT Automation
"@
}

Send-JMLEmail -To @($Global:JML.Notify.ITTeamAddress) `
    -Subject "[JML] Joiner completed: $sam" `
    -Body "Joiner provisioning complete. SAM: $sam | UPN: $upn | OU: $ou | Licence: $($Global:JML.Entra.DefaultLicense)"
#endregion

Write-JMLLog -Level INFO -Message "=== JOINER COMPLETE: $sam ===" -SAMAccountName $sam

[PSCustomObject]@{
    SamAccountName = $sam
    UPN            = $upn
    DisplayName    = $displayName
    TempPassword   = $password
    OU             = $ou
    Groups         = $groups
    LicenceAssigned= $($null -ne $entraUser)
}
