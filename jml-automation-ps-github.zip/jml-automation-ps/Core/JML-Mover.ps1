#Requires -Version 5.1
#Requires -Modules ActiveDirectory
<#
.SYNOPSIS
    JML Mover — Update an existing user on internal transfer / role change

.DESCRIPTION
    Updates AD attributes, moves OU, adjusts group membership, and
    updates the Entra ID display name / department via Graph API.

.PARAMETER SAMAccountName
    Existing AD username.

.PARAMETER Changes
    Hashtable of attributes to change. Supported keys:
        Department, JobTitle, ManagerSAM, OfficeLocation, MobilePhone,
        AddGroups (string[]), RemoveGroups (string[])

.EXAMPLE
    $changes = @{
        Department    = "Finance"
        JobTitle      = "Senior Financial Analyst"
        ManagerSAM    = "smiller"
        AddGroups     = @("Finance-Reports","Budget-Owners")
        RemoveGroups  = @("Engineering-Slack","GitHub-Users")
    }
    .\JML-Mover.ps1 -SAMAccountName "asmith" -Changes $changes
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)][string]$SAMAccountName,
    [Parameter(Mandatory)][hashtable]$Changes
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
. "$root\Config\JML-Config.ps1"
. "$root\Helpers\JML-Helpers.ps1"

Write-JMLLog -Level INFO -Message "=== MOVER START ===" -SAMAccountName $SAMAccountName

#region ── 1. Fetch Existing User ─────────────────────────────────────────────
try {
    $adUser = Get-ADUser -Identity $SAMAccountName `
                         -Properties Department, Title, Manager, MobilePhone,
                                      Office, DistinguishedName, UserPrincipalName `
                         -Server $Global:JML.AD.DomainController
}
catch {
    Write-JMLLog -Level ERROR -Message "User not found: $SAMAccountName" -SAMAccountName $SAMAccountName
    throw
}

$upn = $adUser.UserPrincipalName
Write-JMLLog -Level INFO -Message "Found user: $upn" -SAMAccountName $SAMAccountName
#endregion

#region ── 2. Build AD Attribute Update ───────────────────────────────────────
$setParams  = @{ Server = $Global:JML.AD.DomainController }
$replaceMap = @{}

if ($Changes.Department)    { $replaceMap.Department = $Changes.Department }
if ($Changes.JobTitle)      { $replaceMap.Title       = $Changes.JobTitle }
if ($Changes.OfficeLocation){ $replaceMap.physicalDeliveryOfficeName = $Changes.OfficeLocation }
if ($Changes.MobilePhone)   { $replaceMap.Mobile      = $Changes.MobilePhone }

if ($replaceMap.Count -gt 0) {
    $setParams.Replace = $replaceMap
}

if ($Changes.ManagerSAM) {
    $newMgr = Get-ADUser -Identity $Changes.ManagerSAM -Server $Global:JML.AD.DomainController
    $setParams.Manager = $newMgr.DistinguishedName
}

if ($PSCmdlet.ShouldProcess($SAMAccountName, "Update AD attributes")) {
    if ($setParams.Count -gt 1) {   # More than just Server
        Set-ADUser -Identity $SAMAccountName @setParams
        Write-JMLLog -Level INFO -Message "AD attributes updated: $($replaceMap.Keys -join ', ')" -SAMAccountName $SAMAccountName
    }
}
#endregion

#region ── 3. OU Move ─────────────────────────────────────────────────────────
if ($Changes.Department) {
    $newDept = $Changes.Department
    $targetOU = if ($Global:JML.AD.DeptOUMap.ContainsKey($newDept)) {
                    $Global:JML.AD.DeptOUMap[$newDept]
                } else {
                    $Global:JML.AD.DeptOUMap["Default"]
                }

    $currentOU = ($adUser.DistinguishedName -split ',', 2)[1]
    if ($targetOU -ne $currentOU) {
        if ($PSCmdlet.ShouldProcess($SAMAccountName, "Move OU to $targetOU")) {
            Move-ADObject -Identity $adUser.DistinguishedName -TargetPath $targetOU `
                          -Server $Global:JML.AD.DomainController
            Write-JMLLog -Level INFO -Message "Moved OU: $currentOU → $targetOU" -SAMAccountName $SAMAccountName
        }
    }
}
#endregion

#region ── 4. Group Changes ───────────────────────────────────────────────────
if ($Changes.AddGroups) {
    foreach ($grp in $Changes.AddGroups) {
        try {
            Add-ADGroupMember -Identity $grp -Members $SAMAccountName `
                              -Server $Global:JML.AD.DomainController
            Write-JMLLog -Level INFO -Message "Added to group: $grp" -SAMAccountName $SAMAccountName
        }
        catch { Write-JMLLog -Level WARN -Message "Failed adding to '$grp': $_" -SAMAccountName $SAMAccountName }
    }
}

if ($Changes.RemoveGroups) {
    foreach ($grp in $Changes.RemoveGroups) {
        try {
            Remove-ADGroupMember -Identity $grp -Members $SAMAccountName `
                                 -Server $Global:JML.AD.DomainController -Confirm:$false
            Write-JMLLog -Level INFO -Message "Removed from group: $grp" -SAMAccountName $SAMAccountName
        }
        catch { Write-JMLLog -Level WARN -Message "Failed removing from '$grp': $_" -SAMAccountName $SAMAccountName }
    }
}
#endregion

#region ── 5. Sync & Update Entra ─────────────────────────────────────────────
Invoke-JMLADSync -Wait

# Patch Entra attributes that don't sync from AD by default (e.g. display name variants)
$graphBody = @{}
if ($Changes.Department) { $graphBody.department = $Changes.Department }
if ($Changes.JobTitle)   { $graphBody.jobTitle   = $Changes.JobTitle }

if ($graphBody.Count -gt 0) {
    try {
        Invoke-GraphAPI -Method PATCH -Endpoint "users/$upn" -Body $graphBody
        Write-JMLLog -Level INFO -Message "Entra attributes patched: $($graphBody.Keys -join ', ')" -SAMAccountName $SAMAccountName
    }
    catch {
        Write-JMLLog -Level WARN -Message "Entra PATCH failed: $_" -SAMAccountName $SAMAccountName
    }
}
#endregion

#region ── 6. Notification ────────────────────────────────────────────────────
$changeDesc = ($Changes.GetEnumerator() | Where-Object { $_.Key -notin @("AddGroups","RemoveGroups") } |
    ForEach-Object { "$($_.Key): $($_.Value)" }) -join "`n  "

Send-JMLEmail -To @($Global:JML.Notify.ITTeamAddress) `
    -Subject "[JML] Mover completed: $SAMAccountName" `
    -Body @"
Mover completed for $SAMAccountName.

Changes applied:
  $changeDesc
Added to groups   : $($Changes.AddGroups -join ', ')
Removed from groups: $($Changes.RemoveGroups -join ', ')
"@
#endregion

Write-JMLLog -Level INFO -Message "=== MOVER COMPLETE ===" -SAMAccountName $SAMAccountName
