#Requires -Version 5.1
#Requires -Modules ActiveDirectory
<#
.SYNOPSIS
    JML Leaver — Offboard a departing user from AD + Entra ID

.DESCRIPTION
    Offboarding steps (in order):
        1.  Disable AD account
        2.  Revoke all Entra / Azure tokens (immediate session kill)
        3.  Clear manager attribute
        4.  Remove all AD group memberships (preserves Disabled-Accounts group)
        5.  Move account to Disabled OU
        6.  Update description with offboard date and operator
        7.  Hide from Global Address List (Exchange/EXO)
        8.  Forward mailbox to manager (optional, via EXO)
        9.  Remove M365 licence from Entra
        10. Notify manager + IT

.PARAMETER SAMAccountName
    Account to offboard.

.PARAMETER EffectiveDate
    ISO date (YYYY-MM-DD) that the offboard takes effect. Defaults to today.

.PARAMETER Reason
    Brief reason stored in AD description field (e.g. "Resignation","Termination","Contract end").

.EXAMPLE
    .\JML-Leaver.ps1 -SAMAccountName "asmith" -Reason "Resignation"
#>
[CmdletBinding(SupportsShouldProcess, ConfirmImpact = "High")]
param(
    [Parameter(Mandatory)][string]$SAMAccountName,
    [string]$EffectiveDate = (Get-Date -Format "yyyy-MM-dd"),
    [string]$Reason        = "Leaver"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
. "$root\Config\JML-Config.ps1"
. "$root\Helpers\JML-Helpers.ps1"

Write-JMLLog -Level INFO -Message "=== LEAVER START ===" -SAMAccountName $SAMAccountName

#region ── 1. Fetch User ──────────────────────────────────────────────────────
try {
    $adUser = Get-ADUser -Identity $SAMAccountName `
                         -Properties MemberOf, Manager, UserPrincipalName,
                                      DisplayName, EmailAddress, Enabled `
                         -Server $Global:JML.AD.DomainController
}
catch {
    Write-JMLLog -Level ERROR -Message "User not found: $SAMAccountName" -SAMAccountName $SAMAccountName
    throw
}

if (-not $adUser.Enabled) {
    Write-JMLLog -Level WARN -Message "Account already disabled — re-running offboard steps anyway" -SAMAccountName $SAMAccountName
}

$upn         = $adUser.UserPrincipalName
$displayName = $adUser.DisplayName
$operator    = $env:USERNAME
#endregion

#region ── 2. Disable AD Account ──────────────────────────────────────────────
if ($PSCmdlet.ShouldProcess($SAMAccountName, "Disable AD account")) {
    Disable-ADAccount -Identity $SAMAccountName -Server $Global:JML.AD.DomainController
    Write-JMLLog -Level INFO -Message "AD account disabled" -SAMAccountName $SAMAccountName
}
#endregion

#region ── 3. Revoke Entra Tokens ─────────────────────────────────────────────
if ($Global:JML.Leaver.RevokeTokens) {
    try {
        Invoke-GraphAPI -Method POST `
            -Endpoint "users/$upn/revokeSignInSessions" | Out-Null
        Write-JMLLog -Level INFO -Message "Entra sign-in sessions revoked" -SAMAccountName $SAMAccountName
    }
    catch {
        Write-JMLLog -Level WARN -Message "Token revocation failed: $_" -SAMAccountName $SAMAccountName
    }
}
#endregion

#region ── 4. Resolve Manager Before Clearing ────────────────────────────────
$managerEmail = $null
$managerName  = $null
if ($adUser.Manager) {
    try {
        $mgr          = Get-ADUser -Identity $adUser.Manager -Properties EmailAddress, DisplayName `
                                   -Server $Global:JML.AD.DomainController
        $managerEmail = $mgr.EmailAddress
        $managerName  = $mgr.DisplayName
    }
    catch { Write-JMLLog -Level WARN -Message "Could not resolve manager DN" -SAMAccountName $SAMAccountName }
}
#endregion

#region ── 5. Clear Manager + Random Password ─────────────────────────────────
if ($PSCmdlet.ShouldProcess($SAMAccountName, "Clear manager and randomise password")) {
    # Randomise password so even if account is re-enabled it's unusable
    $junkPwd = New-JMLPassword
    Set-ADAccountPassword -Identity $SAMAccountName `
        -NewPassword (ConvertTo-SecureString $junkPwd -AsPlainText -Force) `
        -Reset -Server $Global:JML.AD.DomainController

    Set-ADUser -Identity $SAMAccountName -Clear Manager -Server $Global:JML.AD.DomainController
    Write-JMLLog -Level INFO -Message "Manager cleared, password randomised" -SAMAccountName $SAMAccountName
}
#endregion

#region ── 6. Remove All Group Memberships ────────────────────────────────────
$removedGroups = @()
foreach ($groupDN in $adUser.MemberOf) {
    try {
        $grpName = (Get-ADGroup -Identity $groupDN).SamAccountName
        if ($grpName -eq "Domain Users") { continue }   # Cannot remove primary group

        Remove-ADGroupMember -Identity $groupDN -Members $SAMAccountName `
                             -Server $Global:JML.AD.DomainController -Confirm:$false
        $removedGroups += $grpName
        Write-JMLLog -Level INFO -Message "Removed from group: $grpName" -SAMAccountName $SAMAccountName
    }
    catch { Write-JMLLog -Level WARN -Message "Failed to remove from group '$groupDN': $_" -SAMAccountName $SAMAccountName }
}
#endregion

#region ── 7. Move to Disabled OU ────────────────────────────────────────────
if ($PSCmdlet.ShouldProcess($SAMAccountName, "Move to Disabled OU")) {
    Move-ADObject -Identity $adUser.DistinguishedName `
                  -TargetPath $Global:JML.AD.DisabledOU `
                  -Server $Global:JML.AD.DomainController
    Write-JMLLog -Level INFO -Message "Moved to Disabled OU: $($Global:JML.AD.DisabledOU)" -SAMAccountName $SAMAccountName
}
#endregion

#region ── 8. Stamp Description ──────────────────────────────────────────────
$desc = "DISABLED $EffectiveDate | Reason: $Reason | By: $operator"
Set-ADUser -Identity $SAMAccountName -Description $desc -Server $Global:JML.AD.DomainController
Write-JMLLog -Level INFO -Message "Description set: $desc" -SAMAccountName $SAMAccountName
#endregion

#region ── 9. Sync → Entra → Remove Licence ──────────────────────────────────
Invoke-JMLADSync -Wait

# Remove all assigned licences
try {
    $assigned = Invoke-GraphAPI -Endpoint "users/$upn/licenseDetails"
    if ($assigned.value.Count -gt 0) {
        $removeLicBody = @{
            addLicenses    = @()
            removeLicenses = @($assigned.value | Select-Object -ExpandProperty skuId)
        }
        Invoke-GraphAPI -Method POST -Endpoint "users/$upn/assignLicense" -Body $removeLicBody | Out-Null
        Write-JMLLog -Level INFO -Message "Removed $($assigned.value.Count) licence(s) from Entra" -SAMAccountName $SAMAccountName
    }
}
catch {
    Write-JMLLog -Level WARN -Message "Licence removal failed: $_" -SAMAccountName $SAMAccountName
}
#endregion

#region ── 10. Hide from GAL ─────────────────────────────────────────────────
# Requires ExchangeOnlineManagement module and connection.
# Uncomment and adjust if EXO is in scope:
#
# try {
#     Set-Mailbox -Identity $upn -HiddenFromAddressListsEnabled $true
#     Set-Mailbox -Identity $upn -ForwardingSmtpAddress $managerEmail -DeliverToMailboxAndForward $false
#     Write-JMLLog -Level INFO -Message "Mailbox hidden from GAL; forwarding to $managerEmail" -SAMAccountName $SAMAccountName
# }
# catch { Write-JMLLog -Level WARN -Message "EXO mailbox step failed: $_" -SAMAccountName $SAMAccountName }
#endregion

#region ── 11. Notifications ─────────────────────────────────────────────────
if ($managerEmail) {
    Send-JMLEmail -To @($managerEmail) `
        -CC @($Global:JML.Notify.ITTeamAddress, $Global:JML.Notify.HRAddress) `
        -Subject "[$displayName] offboarding complete — $EffectiveDate" `
        -Body @"
Hi $managerName,

$displayName's account has been offboarded as of $EffectiveDate.

Actions taken:
  ✓ AD account disabled
  ✓ All sign-in sessions revoked
  ✓ Removed from $($removedGroups.Count) group(s)
  ✓ M365 licences removed
  ✓ Account moved to retention OU (deleted in $($Global:JML.Leaver.RetentionDays) days)

If you need access to their files or mailbox, please raise a request with IT.

— IT Automation
"@
}

Send-JMLEmail -To @($Global:JML.Notify.ITTeamAddress) `
    -Subject "[JML] Leaver completed: $SAMAccountName" `
    -Body "Offboard complete. SAM: $SAMAccountName | UPN: $upn | Reason: $Reason | Groups removed: $($removedGroups.Count)"
#endregion

Write-JMLLog -Level INFO -Message "=== LEAVER COMPLETE ===" -SAMAccountName $SAMAccountName
